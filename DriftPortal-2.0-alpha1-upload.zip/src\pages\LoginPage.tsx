import LockIcon from '@mui/icons-material/Lock';
import { Box, Button, Card, Stack, TextField, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export function LoginPage() {
  const navigate = useNavigate();

  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', p: 2 }}>
      <Card sx={{ width: 'min(420px, 100%)', p: 3 }}>
        <Stack spacing={2}>
          <LockIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h4" sx={{ fontWeight: 800 }}>
            DriftPortal 2.0
          </Typography>
          <Typography sx={{ color: 'text.secondary' }}>
            Login kobles til Supabase Auth i Sprint 1.
          </Typography>
          <TextField label="Email" type="email" />
          <TextField label="Adgangskode" type="password" />
          <Button variant="contained" size="large" onClick={() => navigate('/')}>
            Log ind
          </Button>
        </Stack>
      </Card>
    </Box>
  );
}
